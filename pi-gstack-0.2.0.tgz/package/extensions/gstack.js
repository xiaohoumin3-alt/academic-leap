import { execFile, spawn } from "node:child_process";
import { promises as fs } from "node:fs";
import { homedir } from "node:os";
import path from "node:path";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

const GSTACK_REPO_URL =
	process.env.GSTACK_PI_REPO ?? "https://github.com/garrytan/gstack.git";
const DEFAULT_REF = process.env.GSTACK_PI_REF ?? "main";
const DEFAULT_PREFIX =
	process.env.GSTACK_PI_PREFIX == null
		? true
		: !["0", "false", "no", "off"].includes(
				process.env.GSTACK_PI_PREFIX.toLowerCase(),
			);
const ADAPTER_VERSION = "0.2.0";
const SUBAGENT_TIMEOUT_MS = clampInteger(
	process.env.GSTACK_PI_AGENT_TIMEOUT_MS,
	10 * 60 * 1000,
	1000,
	60 * 60 * 1000,
);
const MAX_TOOL_TEXT = 50 * 1024;
const PI_SUBAGENTS_INSTALL_COMMAND = "pi install npm:pi-subagents";
const DEFAULT_AGENT_TOOLS = "read,bash,grep,find,ls";
const DEFAULT_AGENT_CONTEXT_MODE = "packet";
const DEFAULT_AGENT_CONCURRENCY = 3;
const AGENT_RUN_RETENTION_DAYS = 7;

const SKIP_DIRS = new Set([
	".git",
	"node_modules",
	".agents",
	".claude",
	".codex",
	".factory",
	".opencode",
	".kiro",
	".slate",
	".cursor",
	"dist",
]);

let preparePromise;
let buildNotificationShown = false;
let activeAgentFallbacks = 0;
const agentFallbackQueue = [];

export default function gstackPiExtension(pi) {
	const safety = {
		careful: false,
		guard: false,
		freezeDir: undefined,
	};

	registerCompatibilityTools(pi, safety);
	registerSafetyHooks(pi, safety);

	pi.on("resources_discover", async (_event, ctx) => {
		if (process.env.PI_GSTACK_AGENT_CHILD === "1") return {};
		const paths = getPaths();
		try {
			if (!(await pathExists(path.join(paths.repoDir, ".git")))) {
				notify(
					ctx,
					"gstack-pi first run: cloning Garry Tan's gstack...",
					"info",
				);
			}
			await prepareOnce(paths, { ref: DEFAULT_REF, prefix: DEFAULT_PREFIX });
			if (!buildNotificationShown) {
				buildNotificationShown = true;
				const buildStatus = await getBuildStatus(paths);
				if (!buildStatus.ready) {
					notify(
						ctx,
						`gstack build is ${buildStatus.status}. Run /gstack-build before browser/design/PDF workflows.`,
						"warning",
					);
				}
			}
			await maybeShowSubagentsInstallTip(pi, ctx, paths);
			return { skillPaths: [paths.skillsDir] };
		} catch (error) {
			notify(
				ctx,
				`gstack-pi could not prepare skills: ${formatError(error)}. Run /gstack-sync to retry.`,
				"warning",
			);
			if (await pathExists(paths.skillsDir))
				return { skillPaths: [paths.skillsDir] };
			return {};
		}
	});

	pi.registerCommand("gstack-status", {
		description: "Show gstack-for-Pi install status",
		handler: async (_args, ctx) => {
			const paths = getPaths();
			const status = await getStatus(paths, safety, pi, ctx);
			showMessage(pi, ctx, status);
		},
	});

	pi.registerCommand("gstack-sync", {
		description:
			"Clone or update Garry Tan's gstack repo and regenerate Pi skills. Optional arg: git ref/tag/branch.",
		handler: async (args, ctx) => {
			const paths = getPaths();
			const ref = args?.trim() || DEFAULT_REF;
			notify(ctx, `Syncing gstack (${ref})...`, "info");
			try {
				await syncGstack(paths, ref);
				const result = await generatePiSkills(paths, {
					prefix: DEFAULT_PREFIX,
				});
				preparePromise = undefined;
				const buildStatus = await getBuildStatus(paths);
				const buildNote = buildStatus.ready
					? "Build: ready"
					: `Build: ${buildStatus.status}. Run /gstack-build before browser/design/PDF workflows.`;
				showMessage(
					pi,
					ctx,
					`gstack sync complete.\n\nRepo: ${paths.repoDir}\nGenerated skills: ${result.count}\nPrefix mode: ${DEFAULT_PREFIX ? "gstack-*" : "short names"}\n${buildNote}\n\nReloading Pi resources...`,
				);
				await ctx.reload();
				return;
			} catch (error) {
				showMessage(pi, ctx, `gstack sync failed.\n\n${formatError(error)}`);
			}
		},
	});

	pi.registerCommand("gstack-build", {
		description:
			"Run gstack's Bun build so browser/design/pdf binaries are available to gstack skills",
		handler: async (_args, ctx) => {
			const paths = getPaths();
			try {
				await ensureRepo(paths, DEFAULT_REF);
				notify(
					ctx,
					"Building gstack binaries with Bun. This can take a few minutes...",
					"info",
				);
				const bun = await ensureBun(paths);
				const buildOutput = await runGstackBuild(paths, bun);
				const chromiumOutput = await ensurePlaywrightChromium(paths, bun);
				const codesignOutput = await codesignGstackBinaries(paths);
				await writeBuildMetadata(paths, bun);
				await generatePiSkills(paths, { prefix: DEFAULT_PREFIX });
				preparePromise = undefined;
				const combinedOutput = [buildOutput, chromiumOutput, codesignOutput]
					.filter(Boolean)
					.join("\n");
				const tail = tailLines(combinedOutput.trim(), 100);
				showMessage(
					pi,
					ctx,
					`gstack build complete.\n\nRepo: ${paths.repoDir}\n\nLast build output:\n\n${tail || "(no output)"}\n\nReloading Pi resources...`,
				);
				await ctx.reload();
				return;
			} catch (error) {
				showMessage(
					pi,
					ctx,
					`gstack build failed.\n\n${formatError(error)}\n\nInstall Bun first if needed: https://bun.sh`,
				);
			}
		},
	});
}

function registerCompatibilityTools(pi, safety) {
	pi.registerTool({
		name: "AskUserQuestion",
		label: "Ask User Question",
		description:
			"Pi compatibility tool for gstack's Claude Code AskUserQuestion. Ask the user a structured question and return their answer.",
		promptSnippet:
			"Ask the user a structured question for gstack workflows that require a decision gate.",
		parameters: {
			type: "object",
			additionalProperties: true,
			properties: {
				title: { type: "string" },
				question: { type: "string" },
				message: { type: "string" },
				recommendation: { type: "string" },
				inputType: { type: "string" },
				options: { type: "array", items: {} },
				choices: { type: "array", items: {} },
			},
		},
		prepareArguments(args) {
			if (!args || typeof args !== "object") return args;
			const next = { ...args };
			if (typeof next.options === "string")
				next.options = splitOptionLines(next.options);
			if (typeof next.choices === "string")
				next.choices = splitOptionLines(next.choices);
			if (!next.question && typeof next.prompt === "string")
				next.question = next.prompt;
			return next;
		},
		async execute(_toolCallId, params, _signal, _onUpdate, ctx) {
			return askUserQuestion(params, ctx);
		},
	});

	pi.registerTool({
		name: "gstack_safety",
		label: "GStack Safety",
		description:
			"Activate or inspect Pi-native gstack safety modes: careful, freeze, guard, and unfreeze.",
		promptSnippet:
			"Activate gstack safety modes in Pi when gstack-careful, gstack-freeze, gstack-guard, or gstack-unfreeze is invoked.",
		parameters: {
			type: "object",
			additionalProperties: false,
			properties: {
				action: {
					type: "string",
					enum: ["careful", "freeze", "guard", "unfreeze", "status"],
				},
				directory: { type: "string" },
			},
			required: ["action"],
		},
		prepareArguments(args) {
			if (!args || typeof args !== "object") return args;
			const input = args;
			return {
				action: normalizeSafetyAction(
					input.action ?? input.mode ?? input.command ?? "status",
				),
				directory: input.directory ?? input.dir ?? input.path,
			};
		},
		async execute(_toolCallId, params, _signal, _onUpdate, ctx) {
			const text = await applySafetyAction(
				params.action,
				params.directory,
				ctx,
				safety,
			);
			return {
				content: [{ type: "text", text }],
				details: { ...safety },
			};
		},
	});

	pi.registerTool({
		name: "Agent",
		label: "Agent",
		description:
			"Pi compatibility tool for gstack's Claude Code Agent tool. Runs a focused child Pi session and returns its findings.",
		promptSnippet:
			"Run a focused child Pi session for gstack specialist, adversarial, or audit subagent tasks.",
		parameters: {
			type: "object",
			additionalProperties: true,
			properties: {
				prompt: { type: "string" },
				task: { type: "string" },
				instructions: { type: "string" },
				description: { type: "string" },
				subagent_type: { type: "string" },
				timeoutMs: { type: "number" },
			},
		},
		async execute(_toolCallId, params, signal, onUpdate, ctx) {
			return runAgentCompatibilityTool(params, signal, onUpdate, ctx, pi);
		},
	});

	pi.registerTool({
		name: "Task",
		label: "Task",
		description:
			"Alias for the gstack Agent compatibility tool. Runs a focused child Pi session and returns its findings.",
		parameters: {
			type: "object",
			additionalProperties: true,
			properties: {
				prompt: { type: "string" },
				task: { type: "string" },
				instructions: { type: "string" },
				description: { type: "string" },
				subagent_type: { type: "string" },
				timeoutMs: { type: "number" },
			},
		},
		async execute(_toolCallId, params, signal, onUpdate, ctx) {
			return runAgentCompatibilityTool(params, signal, onUpdate, ctx, pi);
		},
	});

	pi.registerTool({
		name: "TodoWrite",
		label: "Todo Write",
		description:
			"Compatibility no-op for Claude Code TodoWrite. Records a concise todo snapshot in the tool result.",
		parameters: {
			type: "object",
			additionalProperties: true,
			properties: {
				todos: {
					type: "array",
					items: { type: "object", additionalProperties: true },
				},
			},
		},
		async execute(_toolCallId, params) {
			const todos = Array.isArray(params?.todos) ? params.todos : [];
			return {
				content: [
					{
						type: "text",
						text: `Recorded ${todos.length} todo item(s). Keep task progress concise in the final response.`,
					},
				],
				details: { todos },
			};
		},
	});

	pi.registerTool({
		name: "ExitPlanMode",
		label: "Exit Plan Mode",
		description:
			"Compatibility no-op for Claude Code ExitPlanMode. Pi has no separate plan mode.",
		parameters: { type: "object", additionalProperties: true, properties: {} },
		async execute() {
			return {
				content: [
					{
						type: "text",
						text: "Pi has no separate plan mode. Treat the plan-mode workflow as complete and report the final plan or next step.",
					},
				],
				details: {},
				terminate: true,
			};
		},
	});
}

function registerSafetyHooks(pi, safety) {
	pi.on("input", async (event, ctx) => {
		if (event.source === "extension") return { action: "continue" };
		const parsed = parseSafetySkillInvocation(event.text);
		if (!parsed) return { action: "continue" };
		if (!ctx.hasUI) return { action: "continue" };

		if (["careful", "unfreeze"].includes(parsed.action)) {
			const text = await applySafetyAction(
				parsed.action,
				parsed.args,
				ctx,
				safety,
			);
			notify(ctx, text, "info");
			return { action: "handled" };
		}

		if (ctx.hasUI || parsed.args) {
			const text = await applySafetyAction(
				parsed.action,
				parsed.args,
				ctx,
				safety,
			);
			notify(ctx, text, "info");
			return { action: "handled" };
		}

		return { action: "continue" };
	});

	pi.on("tool_call", async (event, ctx) => {
		if ((safety.careful || safety.guard) && event.toolName === "bash") {
			const command = String(event.input?.command ?? "");
			const risk = classifyDestructiveCommand(command);
			if (risk) {
				let allowed = false;
				if (ctx.hasUI) {
					allowed = await ctx.ui.confirm(
						"gstack careful",
						`${risk}\n\nCommand:\n${truncateText(command, 2000)}\n\nAllow this command?`,
					);
				}
				if (!allowed) {
					return { block: true, reason: `Blocked by gstack careful: ${risk}` };
				}
			}
		}

		if (
			(safety.freezeDir || safety.guard) &&
			["edit", "write"].includes(event.toolName)
		) {
			const freezeDir = safety.freezeDir;
			if (!freezeDir) return;
			const target = normalizeToolPath(event.input?.path, ctx.cwd);
			if (target && !isPathInside(target, freezeDir)) {
				return {
					block: true,
					reason: `Blocked by gstack freeze: ${target} is outside ${freezeDir}`,
				};
			}
		}
	});
}

async function askUserQuestion(params, ctx) {
	const question = String(
		params?.question ??
			params?.message ??
			params?.prompt ??
			params?.title ??
			"Question",
	);
	const title = String(params?.title ?? "gstack question");
	const recommendation = params?.recommendation
		? String(params.recommendation)
		: "";
	const options = normalizeOptions(
		params?.options ?? params?.choices ?? params?.answers,
	);
	const inputType = String(
		params?.inputType ?? params?.type ?? (options.length ? "select" : "text"),
	).toLowerCase();
	const message = recommendation
		? `${question}\n\nRecommendation: ${recommendation}`
		: question;

	if (!ctx.hasUI) {
		const optionText = options.length
			? `\nOptions:\n${options.map((o, i) => `${i + 1}. ${o.label}`).join("\n")}`
			: "";
		return {
			content: [
				{
					type: "text",
					text: `Ask the user directly:\n${message}${optionText}`,
				},
			],
			details: { needsUserAnswer: true, question, options },
		};
	}

	if (
		options.length &&
		!["text", "input", "editor", "textarea"].includes(inputType)
	) {
		const labels = options.map((option) => option.label);
		const selected = await ctx.ui.select(message, labels);
		const selectedOption = options.find((option) => option.label === selected);
		return {
			content: [
				{
					type: "text",
					text: selectedOption ? String(selectedOption.value) : "No answer",
				},
			],
			details: { answer: selectedOption?.value, label: selected },
		};
	}

	if (["editor", "textarea", "multiline"].includes(inputType)) {
		const answer = await ctx.ui.editor(title, message);
		return {
			content: [{ type: "text", text: answer ?? "No answer" }],
			details: { answer },
		};
	}

	const answer = await ctx.ui.input(message, "Type your answer");
	return {
		content: [{ type: "text", text: answer ?? "No answer" }],
		details: { answer },
	};
}

function splitOptionLines(value) {
	const lines = String(value)
		.split(/\r?\n/)
		.map((line) => line.trim().replace(/^[-*]\s*/, ""))
		.filter(Boolean);
	return lines.length ? lines : [String(value)];
}

function normalizeSafetyAction(value) {
	const action = String(value || "status")
		.toLowerCase()
		.replace(/[^a-z]+/g, "-");
	if (action.includes("unfreeze") || action.includes("thaw")) return "unfreeze";
	if (action.includes("guard")) return "guard";
	if (action.includes("freeze")) return "freeze";
	if (action.includes("careful") || action.includes("safe")) return "careful";
	return "status";
}

function normalizeOptions(options) {
	if (!Array.isArray(options)) return [];
	return options.map((option) => {
		if (typeof option === "string") return { label: option, value: option };
		const label = String(
			option.label ??
				option.text ??
				option.title ??
				option.value ??
				JSON.stringify(option),
		);
		const value = option.value ?? option.id ?? label;
		return { label, value };
	});
}

async function applySafetyAction(action, directory, ctx, safety) {
	const normalized = String(action || "status").toLowerCase();
	if (normalized === "careful") {
		safety.careful = true;
		return "gstack careful mode active. Destructive bash commands will ask for confirmation.";
	}

	if (normalized === "unfreeze") {
		safety.freezeDir = undefined;
		safety.guard = false;
		await removeFreezeStateFile();
		return "gstack freeze boundary cleared. Edits are allowed everywhere.";
	}

	if (normalized === "freeze" || normalized === "guard") {
		let selectedDir = directory?.trim();
		if (!selectedDir && ctx.hasUI) {
			selectedDir = await ctx.ui.input(
				"Which directory should edits be restricted to?",
				ctx.cwd,
			);
		}
		if (!selectedDir) {
			return "Need a directory path before activating gstack freeze/guard.";
		}
		const freezeDir = normalizeFreezeDir(selectedDir, ctx.cwd);
		safety.freezeDir = freezeDir;
		if (normalized === "freeze") safety.guard = false;
		if (normalized === "guard") {
			safety.guard = true;
			safety.careful = true;
		}
		await writeFreezeStateFile(freezeDir);
		return normalized === "guard"
			? `gstack guard mode active. Destructive commands will ask for confirmation, and edits are restricted to ${freezeDir}`
			: `gstack freeze active. Edits are restricted to ${freezeDir}`;
	}

	return `gstack safety status: careful=${safety.careful}, guard=${safety.guard}, freezeDir=${safety.freezeDir ?? "none"}`;
}

function parseSafetySkillInvocation(text) {
	const trimmed = String(text || "").trim();
	const match = trimmed.match(
		/^\/skill:(?:gstack-)?(careful|freeze|guard|unfreeze)\b\s*(.*)$/,
	);
	if (!match) return undefined;
	return { action: match[1], args: match[2]?.trim() };
}

function classifyDestructiveCommand(command) {
	const text = command.trim();
	if (!text) return undefined;
	if (
		/\brm\s+(?:-[^\n;]*r[^\n;]*f?|--recursive)\b/i.test(text) &&
		!isSafeRmCommand(text)
	) {
		return "recursive delete";
	}
	if (/\bDROP\s+(TABLE|DATABASE|SCHEMA)\b/i.test(text)) return "database drop";
	if (/\bTRUNCATE\b/i.test(text)) return "database truncate";
	if (/\bgit\s+push\b[^\n;]*\s(?:--force|-f)\b/i.test(text))
		return "force push";
	if (/\bgit\s+reset\s+--hard\b/i.test(text)) return "hard reset";
	if (/\bgit\s+(checkout|restore)\s+\.\s*($|[;&|])/i.test(`${text} `))
		return "restore all files";
	if (/\bkubectl\s+delete\b/i.test(text)) return "kubectl delete";
	if (/\bdocker\s+(rm\s+-f|system\s+prune)\b/i.test(text))
		return "docker destructive operation";
	return undefined;
}

function isSafeRmCommand(command) {
	const safeTargets = [
		"node_modules",
		".next",
		"dist",
		"__pycache__",
		".cache",
		"build",
		".turbo",
		"coverage",
	];
	return safeTargets.some((target) =>
		new RegExp(`\\brm\\s+[^\n;]*\\b${escapeRegex(target)}\\b`).test(command),
	);
}

function normalizeToolPath(inputPath, cwd) {
	if (typeof inputPath !== "string" || !inputPath) return undefined;
	const clean = inputPath.startsWith("@") ? inputPath.slice(1) : inputPath;
	return path.resolve(cwd || process.cwd(), clean);
}

function normalizeFreezeDir(inputPath, cwd) {
	const clean = inputPath.startsWith("@") ? inputPath.slice(1) : inputPath;
	return path.resolve(cwd || process.cwd(), clean);
}

function isPathInside(target, root) {
	const relative = path.relative(root, target);
	return (
		relative === "" ||
		(!relative.startsWith("..") && !path.isAbsolute(relative))
	);
}

async function writeFreezeStateFile(freezeDir) {
	const stateDir =
		process.env.CLAUDE_PLUGIN_DATA || path.join(homedir(), ".gstack");
	await fs.mkdir(stateDir, { recursive: true });
	await fs.writeFile(
		path.join(stateDir, "freeze-dir.txt"),
		`${freezeDir}${path.sep}`,
		"utf8",
	);
}

async function removeFreezeStateFile() {
	const stateDir =
		process.env.CLAUDE_PLUGIN_DATA || path.join(homedir(), ".gstack");
	await fs.rm(path.join(stateDir, "freeze-dir.txt"), { force: true });
}

function hasPiSubagents(pi) {
	try {
		return (
			pi.getAllTools?.()?.some((tool) => tool?.name === "subagent") ||
			pi.getActiveTools?.().includes("subagent") ||
			false
		);
	} catch {
		return false;
	}
}

async function maybeShowSubagentsInstallTip(pi, ctx, paths) {
	if (hasPiSubagents(pi) || !ctx?.hasUI) return;
	const marker = subagentsStartupTipPath(paths);
	if (await pathExists(marker)) return;
	await fs.mkdir(paths.baseDir, { recursive: true });
	await fs.writeFile(marker, new Date().toISOString(), "utf8");
	notify(
		ctx,
		`pi-gstack works standalone. For best review/ship/autoplan specialist agents, install native Pi subagents: ${PI_SUBAGENTS_INSTALL_COMMAND}`,
		"info",
	);
}

async function maybeGetAgentFallbackTip(pi, ctx, paths) {
	if (hasPiSubagents(pi)) return "";
	const marker = agentFallbackTipPath(paths);
	if (await pathExists(marker)) return "";
	await fs.mkdir(paths.baseDir, { recursive: true });
	await fs.writeFile(marker, new Date().toISOString(), "utf8");
	const tip = [
		"Using pi-gstack's built-in Agent/Task fallback.",
		"",
		"For higher-fidelity native Pi subagents, install:",
		"",
		`  ${PI_SUBAGENTS_INSTALL_COMMAND}`,
		"",
		"The fallback is supported, but pi-subagents adds forked context, progress tracking, async runs, chains, and worktree isolation.",
	].join("\n");
	if (ctx?.hasUI) {
		notify(
			ctx,
			`Using Agent/Task fallback. For native Pi subagents: ${PI_SUBAGENTS_INSTALL_COMMAND}`,
			"info",
		);
	}
	return tip;
}

function subagentsStartupTipPath(paths) {
	return path.join(paths.baseDir, ".subagents-tip-shown");
}

function agentFallbackTipPath(paths) {
	return path.join(paths.baseDir, ".agent-fallback-tip-shown");
}

function withOptionalPrefix(prefix, text) {
	return prefix ? `${prefix}\n\n---\n\n${text}` : text;
}

async function runAgentCompatibilityTool(params, signal, onUpdate, ctx, pi) {
	const prompt = String(
		params?.prompt ??
			params?.task ??
			params?.instructions ??
			params?.description ??
			"",
	).trim();
	if (!prompt) {
		return {
			content: [{ type: "text", text: "No subagent prompt was provided." }],
			details: {},
		};
	}
	if (process.env.PI_GSTACK_AGENT_CHILD === "1") {
		return {
			content: [
				{
					type: "text",
					text: "Nested Agent calls are disabled in pi-gstack child sessions. Complete this analysis inline and report findings directly.",
				},
			],
			details: { nested: true },
		};
	}

	const paths = getPaths();
	const settings = getAgentFallbackSettings(ctx, pi);
	const timeout = clampInteger(
		params?.timeoutMs,
		SUBAGENT_TIMEOUT_MS,
		1000,
		60 * 60 * 1000,
	);
	const fallbackTip = await maybeGetAgentFallbackTip(pi, ctx, paths);

	return withAgentFallbackSlot(settings.concurrency, onUpdate, async () => {
		onUpdate?.({
			content: [
				{
					type: "text",
					text: `Starting focused Pi child session (${settings.tools || "default tools"})...`,
				},
			],
		});

		await cleanupOldAgentRuns(paths);
		const runDir = await createAgentRunDir(paths);
		const contextFile = path.join(runDir, "context.md");
		const taskFile = path.join(runDir, "task.md");
		const systemFile = path.join(runDir, "system.md");
		const outputFile = path.join(runDir, "output.txt");

		await fs.writeFile(
			contextFile,
			await buildAgentContextPacket(ctx, paths, settings, params),
			"utf8",
		);
		await fs.writeFile(taskFile, buildAgentTaskPrompt(prompt, params), "utf8");
		await fs.writeFile(systemFile, buildAgentSystemPrompt(settings), "utf8");

		try {
			const result = await runProcess(
				"pi",
				buildAgentPiArgs(contextFile, taskFile, systemFile, settings),
				{
					cwd: ctx?.cwd || process.cwd(),
					timeout,
					maxBuffer: 1024 * 1024,
					env: {
						PI_GSTACK_AGENT_CHILD: "1",
						PI_SKIP_VERSION_CHECK: "1",
					},
					signal,
				},
			);
			const output = truncateText(
				`${result.stdout}\n${result.stderr}`.trim(),
				MAX_TOOL_TEXT,
			);
			await fs.writeFile(outputFile, output, "utf8");
			return {
				content: [
					{
						type: "text",
						text: withOptionalPrefix(
							fallbackTip,
							output || "Child Pi session completed with no output.",
						),
					},
				],
				details: {
					runtime: "pi-gstack-fallback",
					runDir,
					contextFile,
					taskFile,
					outputFile,
					timeout,
					settings,
				},
			};
		} catch (error) {
			await fs.writeFile(outputFile, formatError(error), "utf8");
			return {
				content: [
					{
						type: "text",
						text: withOptionalPrefix(
							fallbackTip,
							`Child Pi session unavailable: ${formatError(error)}\n\nFallback: complete this subagent task inline in the current session.\n\nDebug artifacts: ${runDir}`,
						),
					},
				],
				details: {
					error: formatError(error),
					runtime: "pi-gstack-fallback",
					runDir,
					contextFile,
					taskFile,
					outputFile,
					timeout,
					settings,
				},
			};
		}
	});
}

function getAgentFallbackSettings(ctx, pi) {
	const model = process.env.GSTACK_PI_AGENT_MODEL || getParentModelSpec(ctx);
	const thinking =
		process.env.GSTACK_PI_AGENT_THINKING ||
		safeCall(() => ctx?.getThinkingLevel?.()) ||
		safeCall(() => pi?.getThinkingLevel?.());
	return {
		model,
		thinking,
		tools: process.env.GSTACK_PI_AGENT_TOOLS || DEFAULT_AGENT_TOOLS,
		contextMode:
			process.env.GSTACK_PI_AGENT_CONTEXT_MODE || DEFAULT_AGENT_CONTEXT_MODE,
		concurrency: clampInteger(
			process.env.GSTACK_PI_AGENT_CONCURRENCY,
			DEFAULT_AGENT_CONCURRENCY,
			1,
			12,
		),
	};
}

function getParentModelSpec(ctx) {
	const model = ctx?.model;
	if (!model?.id) return "";
	if (!model.provider) return model.id;
	if (model.id.startsWith(`${model.provider}/`)) return model.id;
	return `${model.provider}/${model.id}`;
}

function buildAgentPiArgs(contextFile, taskFile, systemFile, settings) {
	const args = [
		"--no-session",
		"--no-skills",
		"--no-prompt-templates",
		"--append-system-prompt",
		systemFile,
	];
	if (settings.model) args.push("--model", settings.model);
	if (settings.thinking) args.push("--thinking", settings.thinking);
	if (settings.tools && settings.tools !== "all")
		args.push("--tools", settings.tools);
	args.push(
		"-p",
		`@${contextFile}`,
		`@${taskFile}`,
		"Complete the attached gstack child-agent task. Return only the requested markdown report.",
	);
	return args;
}

function buildAgentSystemPrompt(settings) {
	return [
		"You are a focused pi-gstack child Agent/Task fallback runner.",
		"",
		"You provide an independent specialist analysis for a parent gstack workflow.",
		"Rules:",
		"- Do not call Agent, Task, AskUserQuestion, TodoWrite, or ExitPlanMode.",
		"- Do not ask the user questions; make reasonable assumptions and state uncertainty.",
		"- Do not edit files unless the task explicitly asks and write tools are enabled.",
		"- Prefer evidence from repository files and command output over speculation.",
		"- Keep the response concise and directly usable by the parent agent.",
		"",
		`Runtime mode: ${settings.contextMode}`,
		`Allowed tools: ${settings.tools || "default"}`,
	].join("\n");
}

function buildAgentTaskPrompt(prompt, params) {
	return [
		"# gstack child-agent task",
		"",
		params?.subagent_type ? `Specialist type: ${params.subagent_type}` : "",
		params?.description ? `Description: ${params.description}` : "",
		"",
		"## Task",
		"",
		prompt,
		"",
		"## Required output format",
		"",
		"Return markdown with these sections:",
		"",
		"## Verdict",
		"One-sentence bottom line.",
		"",
		"## Findings",
		"Bulleted findings, ordered by severity or importance.",
		"",
		"## Evidence",
		"Files, commands, observations, or reasoning supporting the findings.",
		"",
		"## Risks",
		"Known uncertainty, missing context, or likely failure modes.",
		"",
		"## Recommended action",
		"Concrete next steps for the parent agent.",
	]
		.filter(Boolean)
		.join("\n");
}

async function buildAgentContextPacket(ctx, paths, settings, params) {
	const cwd = ctx?.cwd || process.cwd();
	const [branch, status, diffStat] = await Promise.all([
		safeRunText("git", ["branch", "--show-current"], cwd),
		safeRunText("git", ["status", "--short"], cwd),
		safeRunText("git", ["diff", "--stat"], cwd),
	]);
	const recentMessages = getRecentUserMessages(ctx, 4);
	return [
		"# gstack child-agent context packet",
		"",
		`Generated: ${new Date().toISOString()}`,
		`Working directory: ${cwd}`,
		`gstack runtime path: ${paths.repoDir}`,
		`Parent model: ${settings.model || "default"}`,
		`Parent thinking: ${settings.thinking || "default"}`,
		`Tool allowlist: ${settings.tools || "default"}`,
		`Context mode: ${settings.contextMode}`,
		params?.subagent_type
			? `Requested specialist: ${params.subagent_type}`
			: "",
		params?.description ? `Task description: ${params.description}` : "",
		"",
		"## Git state",
		"",
		`Branch: ${branch || "unknown"}`,
		"",
		"Status:",
		"```text",
		status || "clean or unavailable",
		"```",
		"",
		"Diff stat:",
		"```text",
		diffStat || "none or unavailable",
		"```",
		"",
		"## Recent user messages",
		"",
		...(recentMessages.length
			? recentMessages.map((message, index) => `${index + 1}. ${message}`)
			: ["No recent user messages available from the parent session."]),
		"",
		"## Independence contract",
		"",
		"Treat this as a fresh, independent specialist pass. Do not assume the parent agent's conclusions are correct. Report disagreement plainly.",
	]
		.filter(Boolean)
		.join("\n");
}

function getRecentUserMessages(ctx, limit) {
	let entries = [];
	try {
		entries =
			ctx?.sessionManager?.getBranch?.() ||
			ctx?.sessionManager?.getEntries?.() ||
			[];
	} catch {
		entries = [];
	}
	const messages = [];
	for (const entry of [...entries].reverse()) {
		const message = entry?.type === "message" ? entry.message : undefined;
		if (message?.role !== "user") continue;
		messages.push(truncateText(extractMessageText(message.content), 500));
		if (messages.length >= limit) break;
	}
	return messages.reverse();
}

function extractMessageText(content) {
	if (typeof content === "string") return content;
	if (Array.isArray(content)) {
		return content
			.map((part) =>
				part?.type === "text" ? part.text : `[${part?.type || "content"}]`,
			)
			.join(" ");
	}
	return String(content ?? "");
}

async function withAgentFallbackSlot(concurrency, onUpdate, fn) {
	if (activeAgentFallbacks >= concurrency) {
		onUpdate?.({
			content: [
				{
					type: "text",
					text: `Waiting for Agent/Task fallback slot (${activeAgentFallbacks}/${concurrency} active)...`,
				},
			],
		});
		await new Promise((resolve) => agentFallbackQueue.push(resolve));
	}
	activeAgentFallbacks += 1;
	try {
		return await fn();
	} finally {
		activeAgentFallbacks -= 1;
		const next = agentFallbackQueue.shift();
		if (next) next();
	}
}

async function createAgentRunDir(paths) {
	const runId = `${new Date().toISOString().replace(/[:.]/g, "-")}-${Math.random().toString(36).slice(2, 8)}`;
	const dir = path.join(paths.baseDir, "agent-runs", runId);
	await fs.mkdir(dir, { recursive: true });
	return dir;
}

async function cleanupOldAgentRuns(paths) {
	const dir = path.join(paths.baseDir, "agent-runs");
	let entries;
	try {
		entries = await fs.readdir(dir, { withFileTypes: true });
	} catch {
		return;
	}
	const cutoff = Date.now() - AGENT_RUN_RETENTION_DAYS * 24 * 60 * 60 * 1000;
	await Promise.all(
		entries
			.filter((entry) => entry.isDirectory())
			.map(async (entry) => {
				const fullPath = path.join(dir, entry.name);
				try {
					const stat = await fs.stat(fullPath);
					if (stat.mtimeMs < cutoff) {
						await fs.rm(fullPath, { recursive: true, force: true });
					}
				} catch {
					// Ignore cleanup failures.
				}
			}),
	);
}

async function safeRunText(command, args, cwd) {
	try {
		const result = await run(command, args, {
			cwd,
			timeout: 10 * 1000,
			maxBuffer: 256 * 1024,
		});
		return truncateText(`${result.stdout}\n${result.stderr}`.trim(), 4000);
	} catch {
		return "";
	}
}

function clampInteger(value, fallback, min, max) {
	const parsed = Number.parseInt(value, 10);
	if (!Number.isFinite(parsed)) return fallback;
	return Math.max(min, Math.min(max, parsed));
}

function safeCall(fn) {
	try {
		return fn();
	} catch {
		return undefined;
	}
}

async function runProcess(command, args, options = {}) {
	return new Promise((resolve, reject) => {
		if (options.signal?.aborted) {
			reject(new Error(`${command} aborted`));
			return;
		}
		const child = spawn(command, args, {
			cwd: options.cwd,
			env: { ...process.env, ...(options.env ?? {}) },
			detached: process.platform !== "win32",
			stdio: ["ignore", "pipe", "pipe"],
		});
		let stdout = "";
		let stderr = "";
		let settled = false;
		let killTimer;
		const timeoutTimer = options.timeout
			? setTimeout(() => {
					terminateProcessTree(child);
					rejectOnce(
						new Error(`${command} timed out after ${options.timeout}ms`),
					);
				}, options.timeout)
			: undefined;
		const append = (current, chunk) => {
			const next = current + chunk.toString();
			const max = options.maxBuffer ?? 1024 * 1024;
			return next.length > max ? next.slice(next.length - max) : next;
		};
		const cleanup = () => {
			if (timeoutTimer) clearTimeout(timeoutTimer);
			options.signal?.removeEventListener?.("abort", onAbort);
		};
		const rejectOnce = (error) => {
			if (settled) return;
			settled = true;
			cleanup();
			error.stdout = stdout;
			error.stderr = stderr;
			reject(error);
		};
		const resolveOnce = (result) => {
			if (settled) return;
			settled = true;
			cleanup();
			resolve(result);
		};
		const onAbort = () => {
			terminateProcessTree(child);
			rejectOnce(new Error(`${command} aborted`));
		};
		options.signal?.addEventListener?.("abort", onAbort, { once: true });
		child.stdout?.on("data", (chunk) => {
			stdout = append(stdout, chunk);
		});
		child.stderr?.on("data", (chunk) => {
			stderr = append(stderr, chunk);
		});
		child.on("error", rejectOnce);
		child.on("close", (code, childSignal) => {
			if (killTimer) clearTimeout(killTimer);
			if (code === 0) {
				resolveOnce({ stdout, stderr });
				return;
			}
			const codeText = code == null ? "" : ` (exit ${code})`;
			const signalText = childSignal ? ` (signal ${childSignal})` : "";
			rejectOnce(
				new Error(
					`${command} ${args.join(" ")} failed${codeText}${signalText}.${stdout ? `\nstdout:\n${tailLines(stdout, 80)}` : ""}${stderr ? `\nstderr:\n${tailLines(stderr, 80)}` : ""}`,
				),
			);
		});
		function terminateProcessTree(target) {
			if (!target.pid) return;
			try {
				if (process.platform === "win32") {
					target.kill("SIGTERM");
				} else {
					process.kill(-target.pid, "SIGTERM");
				}
			} catch {
				// Ignore first kill failure.
			}
			killTimer = setTimeout(() => {
				try {
					if (process.platform === "win32") {
						target.kill("SIGKILL");
					} else {
						process.kill(-target.pid, "SIGKILL");
					}
				} catch {
					// Ignore kill failure.
				}
			}, 2500);
		}
	});
}

async function prepareOnce(paths, options) {
	if (!preparePromise) {
		preparePromise = ensurePrepared(paths, options).catch((error) => {
			preparePromise = undefined;
			throw error;
		});
	}
	return preparePromise;
}

async function ensurePrepared(paths, options) {
	await ensureRepo(paths, options.ref);
	if (await shouldGenerate(paths, options)) {
		await generatePiSkills(paths, { prefix: options.prefix });
	}
}

async function shouldGenerate(paths, options) {
	if (!(await pathExists(paths.skillsDir))) return true;
	if (await isDirEmpty(paths.skillsDir)) return true;

	try {
		const raw = await fs.readFile(
			path.join(paths.skillsDir, ".gstack-pi.json"),
			"utf8",
		);
		const metadata = JSON.parse(raw);
		return (
			metadata.adapterVersion !== ADAPTER_VERSION ||
			metadata.prefix !== options.prefix
		);
	} catch {
		return true;
	}
}

export function getPaths() {
	const piDir =
		process.env.PI_CODING_AGENT_DIR || path.join(homedir(), ".pi", "agent");
	const baseDir = process.env.GSTACK_PI_HOME || path.join(piDir, "gstack-pi");
	return {
		piDir,
		baseDir,
		repoDir: path.join(baseDir, "repo"),
		skillsDir: path.join(baseDir, "skills"),
	};
}

async function ensureRepo(paths, ref) {
	if (await pathExists(path.join(paths.repoDir, ".git"))) return;

	if (
		process.env.GSTACK_PI_AUTO_CLONE &&
		["0", "false", "no", "off"].includes(
			process.env.GSTACK_PI_AUTO_CLONE.toLowerCase(),
		)
	) {
		throw new Error(
			`gstack repo is missing at ${paths.repoDir} and GSTACK_PI_AUTO_CLONE is disabled`,
		);
	}

	await fs.mkdir(paths.baseDir, { recursive: true });
	await fs.rm(paths.repoDir, { recursive: true, force: true });
	await run("git", ["clone", "--depth", "1", GSTACK_REPO_URL, paths.repoDir], {
		timeout: 5 * 60 * 1000,
		maxBuffer: 20 * 1024 * 1024,
	});
	if (ref && ref !== "main" && ref !== "HEAD")
		await checkoutRef(paths.repoDir, ref);
}

async function syncGstack(paths, ref) {
	await ensureRepo(paths, ref);
	await checkoutRef(paths.repoDir, ref || DEFAULT_REF);
}

async function checkoutRef(repoDir, ref) {
	await run("git", ["fetch", "--depth", "1", "origin", ref], {
		cwd: repoDir,
		timeout: 5 * 60 * 1000,
		maxBuffer: 20 * 1024 * 1024,
	});
	await run("git", ["checkout", "--detach", "FETCH_HEAD"], {
		cwd: repoDir,
		timeout: 60 * 1000,
		maxBuffer: 10 * 1024 * 1024,
	});
	await run("git", ["reset", "--hard", "FETCH_HEAD"], {
		cwd: repoDir,
		timeout: 60 * 1000,
		maxBuffer: 10 * 1024 * 1024,
	});
}

async function ensureBun(paths) {
	const bun = await resolveBunBin();
	if (!bun) {
		throw new Error(
			"Bun is required. Install it from https://bun.sh, then run /gstack-build again.",
		);
	}
	await ensureBunShim(paths, bun);
	return bun;
}

async function resolveBunBin() {
	if (process.env.BUN && (await pathExists(process.env.BUN)))
		return process.env.BUN;
	try {
		const result = await run("bash", ["-lc", "command -v bun"], {
			timeout: 10 * 1000,
			maxBuffer: 1024 * 1024,
		});
		const fromPath = result.stdout.trim();
		if (fromPath) return fromPath;
	} catch {
		// Fall through to common locations.
	}
	const candidates = [
		path.join(homedir(), ".bun", "bin", "bun"),
		"/opt/homebrew/bin/bun",
		"/usr/local/bin/bun",
	];
	for (const candidate of candidates) {
		if (await pathExists(candidate)) return candidate;
	}
	return undefined;
}

async function ensureBunShim(paths, bunPath) {
	const binDir = path.join(paths.piDir, "bin");
	await fs.mkdir(binDir, { recursive: true });
	const shimPath = path.join(binDir, "bun");
	try {
		const stat = await fs.lstat(shimPath);
		if (stat.isSymbolicLink()) {
			const current = await fs.readlink(shimPath);
			if (current === bunPath) return;
			await fs.rm(shimPath, { force: true });
		} else {
			return;
		}
	} catch {
		// Missing shim.
	}
	await fs.symlink(bunPath, shimPath);
}

async function runGstackBuild(paths, bun) {
	const bunQ = shellQuote(bun);
	const script = `${bunQ} install --frozen-lockfile 2>/dev/null || ${bunQ} install\n${bunQ} run build`;
	const result = await run("bash", ["-lc", script], {
		cwd: paths.repoDir,
		timeout: 30 * 60 * 1000,
		maxBuffer: 50 * 1024 * 1024,
		env: { PATH: prependPath(path.dirname(bun)) },
	});
	return `${result.stdout}\n${result.stderr}`;
}

async function ensurePlaywrightChromium(paths, bun) {
	const verifyArgs = [
		"--eval",
		'import { chromium } from "playwright"; const browser = await chromium.launch(); await browser.close();',
	];
	try {
		const result = await run(bun, verifyArgs, {
			cwd: paths.repoDir,
			timeout: 60 * 1000,
			maxBuffer: 5 * 1024 * 1024,
			env: { PATH: prependPath(path.dirname(bun)) },
		});
		return `Playwright Chromium verified.\n${result.stdout}${result.stderr}`;
	} catch {
		const install = await run(bun, ["x", "playwright", "install", "chromium"], {
			cwd: paths.repoDir,
			timeout: 10 * 60 * 1000,
			maxBuffer: 20 * 1024 * 1024,
			env: { PATH: prependPath(path.dirname(bun)) },
		});
		const verify = await run(bun, verifyArgs, {
			cwd: paths.repoDir,
			timeout: 60 * 1000,
			maxBuffer: 5 * 1024 * 1024,
			env: { PATH: prependPath(path.dirname(bun)) },
		});
		return `Installed Playwright Chromium.\n${install.stdout}${install.stderr}\n${verify.stdout}${verify.stderr}`;
	}
}

async function codesignGstackBinaries(paths) {
	if (process.platform !== "darwin" || process.arch !== "arm64") return "";
	const script = `for _bin in browse/dist/browse browse/dist/find-browse design/dist/design make-pdf/dist/pdf bin/gstack-global-discover; do
  _bin_path=${shellQuote(paths.repoDir)}/$_bin
  [ -f "$_bin_path" ] && [ -x "$_bin_path" ] || continue
  codesign --remove-signature "$_bin_path" 2>/dev/null || true
  codesign -s - -f "$_bin_path" 2>/dev/null || echo "warning: codesign failed for $_bin"
done`;
	const result = await run("bash", ["-lc", script], {
		timeout: 60 * 1000,
		maxBuffer: 2 * 1024 * 1024,
	});
	return `${result.stdout}\n${result.stderr}`;
}

async function writeBuildMetadata(paths, bunPath) {
	const commit = await safeGit(paths.repoDir, ["rev-parse", "HEAD"]);
	await fs.writeFile(
		buildMetadataPath(paths),
		JSON.stringify(
			{
				adapterVersion: ADAPTER_VERSION,
				gstackCommit: commit,
				bunPath,
				builtAt: new Date().toISOString(),
				ok: true,
			},
			null,
			2,
		),
		"utf8",
	);
}

async function run(command, args, options = {}) {
	try {
		const result = await execFileAsync(command, args, {
			cwd: options.cwd,
			env: { ...process.env, ...(options.env ?? {}) },
			timeout: options.timeout ?? 120 * 1000,
			maxBuffer: options.maxBuffer ?? 10 * 1024 * 1024,
			signal: options.signal,
		});
		return { stdout: result.stdout ?? "", stderr: result.stderr ?? "" };
	} catch (error) {
		const stdout = error.stdout
			? `\nstdout:\n${tailLines(String(error.stdout), 120)}`
			: "";
		const stderr = error.stderr
			? `\nstderr:\n${tailLines(String(error.stderr), 120)}`
			: "";
		const code = error.code == null ? "" : ` (exit ${error.code})`;
		throw new Error(
			`${command} ${args.join(" ")} failed${code}.${stdout}${stderr}`,
		);
	}
}

export async function generatePiSkills(paths, options = {}) {
	const prefix = options.prefix ?? true;
	const skillFiles = await collectSkillFiles(paths.repoDir);
	const parsed = [];

	for (const file of skillFiles) {
		const raw = await fs.readFile(file, "utf8");
		const skill = parseSkill(raw, file, paths.repoDir);
		if (!skill.description) continue;
		parsed.push(skill);
	}

	const nameCounts = new Map();
	const nameMap = new Map();
	for (const skill of parsed) {
		const base = sanitizeSkillName(
			skill.name || skill.sourceDirName || "gstack",
		);
		let outputName =
			prefix && base !== "gstack" && !base.startsWith("gstack-")
				? `gstack-${base}`
				: base;
		const count = nameCounts.get(outputName) ?? 0;
		nameCounts.set(outputName, count + 1);
		if (count > 0) outputName = `${outputName}-${count + 1}`;
		skill.outputName = outputName;
		nameMap.set(base, outputName);
		nameMap.set(outputName, outputName);
		if (skill.name) nameMap.set(sanitizeSkillName(skill.name), outputName);
	}

	await fs.rm(paths.skillsDir, { recursive: true, force: true });
	await fs.mkdir(paths.skillsDir, { recursive: true });

	for (const skill of parsed) {
		const outDir = path.join(paths.skillsDir, skill.outputName);
		await fs.mkdir(outDir, { recursive: true });
		const transformed = transformSkill(skill, paths, nameMap);
		await fs.writeFile(path.join(outDir, "SKILL.md"), transformed, "utf8");
	}

	await fs.writeFile(
		path.join(paths.skillsDir, ".gstack-pi.json"),
		JSON.stringify(
			{
				adapterVersion: ADAPTER_VERSION,
				generatedAt: new Date().toISOString(),
				repo: GSTACK_REPO_URL,
				repoDir: paths.repoDir,
				prefix,
				count: parsed.length,
			},
			null,
			2,
		),
		"utf8",
	);

	return { count: parsed.length, skillsDir: paths.skillsDir };
}

async function collectSkillFiles(root) {
	const out = [];
	async function walk(dir) {
		const base = path.basename(dir);
		if (dir !== root && base.startsWith(".")) return;
		if (SKIP_DIRS.has(base)) return;

		let entries;
		try {
			entries = await fs.readdir(dir, { withFileTypes: true });
		} catch {
			return;
		}

		if (entries.some((entry) => entry.isFile() && entry.name === "SKILL.md")) {
			out.push(path.join(dir, "SKILL.md"));
		}

		for (const entry of entries) {
			if (!entry.isDirectory()) continue;
			await walk(path.join(dir, entry.name));
		}
	}

	await walk(root);
	out.sort((a, b) =>
		relativePosix(root, a).localeCompare(relativePosix(root, b)),
	);
	return out;
}

export function parseSkill(raw, file, repoDir) {
	const parsed = splitFrontmatter(raw);
	const sourceDirName = path.basename(path.dirname(file));
	const name =
		extractFrontmatterField(parsed.frontmatter, "name") ||
		(file === path.join(repoDir, "SKILL.md") ? "gstack" : sourceDirName);
	const description =
		extractFrontmatterField(parsed.frontmatter, "description") ||
		`gstack skill from ${relativePosix(repoDir, file)}`;
	return {
		file,
		sourceDirName,
		name,
		description: normalizeDescription(description),
		body: parsed.body,
	};
}

function splitFrontmatter(raw) {
	if (!raw.startsWith("---")) return { frontmatter: "", body: raw };
	const match = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
	if (!match) return { frontmatter: "", body: raw };
	return { frontmatter: match[1], body: raw.slice(match[0].length) };
}

function extractFrontmatterField(frontmatter, field) {
	if (!frontmatter) return "";
	const lines = frontmatter.split(/\r?\n/);
	for (let i = 0; i < lines.length; i += 1) {
		const match = lines[i].match(
			new RegExp(`^${escapeRegex(field)}:\\s*(.*)$`),
		);
		if (!match) continue;
		const rest = match[1].trim();
		if (rest === "|" || rest === ">" || rest.startsWith("|")) {
			const block = [];
			for (let j = i + 1; j < lines.length; j += 1) {
				const line = lines[j];
				if (/^[A-Za-z0-9_-]+:\s*/.test(line)) break;
				block.push(line.replace(/^\s{2,}/, ""));
			}
			return block.join(" ").replace(/\s+/g, " ").trim();
		}
		return stripQuotes(rest).trim();
	}
	return "";
}

function transformSkill(skill, paths, nameMap) {
	const repoPath = toPosixPath(paths.repoDir);
	const piSkillsPath = toPosixPath(path.join(paths.piDir, "skills"));
	const sourcePath = relativePosix(paths.repoDir, skill.file);

	const isUpgradeSkill =
		sanitizeSkillName(skill.name) === "gstack-upgrade" ||
		skill.sourceDirName === "gstack-upgrade";
	let body = skill.body;
	if (isSafetySkill(skill)) body = piSafetySkillBody(skill);
	if (isUpgradeSkill) body = piUpgradeSkillBody();
	body = rewriteGstackPaths(body, repoPath, piSkillsPath);
	body = rewriteSkillCommands(body, nameMap);
	body = body.replace(/\bSkill tool\b/g, "Pi skill command (`/skill:name`)");
	body = body.replace(/<SKILL_DIR>/g, repoPath);
	body = rewritePiHostAssumptions(body);

	const description = isUpgradeSkill
		? "Update pi-gstack and the Pi-managed upstream gstack checkout. Use when asked to upgrade or update gstack in Pi."
		: rewriteSkillCommands(skill.description, nameMap);
	const frontmatter = [
		"---",
		`name: ${skill.outputName}`,
		"description: |",
		...wrapDescription(description).map((line) => `  ${line}`),
		"license: MIT",
		"metadata:",
		"  upstream: https://github.com/garrytan/gstack",
		`  source: ${sourcePath}`,
		"---",
		"",
	].join("\n");

	return `${frontmatter}${piCompatibilityNote(repoPath)}\n${body}`;
}

function isSafetySkill(skill) {
	const name = sanitizeSkillName(skill.name || skill.sourceDirName);
	return [
		"careful",
		"freeze",
		"guard",
		"unfreeze",
		"gstack-careful",
		"gstack-freeze",
		"gstack-guard",
		"gstack-unfreeze",
	].includes(name);
}

function piSafetySkillBody(skill) {
	const name = sanitizeSkillName(skill.name || skill.sourceDirName).replace(
		/^gstack-/,
		"",
	);
	const action = ["careful", "freeze", "guard", "unfreeze"].includes(name)
		? name
		: "status";
	return `# Pi-native gstack ${action}

This Pi adapter implements gstack safety behavior with extension hooks, not Claude Code hooks.

Immediately call the \`gstack_safety\` tool with:

\`\`\`json
{ "action": "${action}" }
\`\`\`

For \`freeze\` and \`guard\`, include a \`directory\` argument if the user supplied one. If no directory was supplied, call \`gstack_safety\` without \`directory\`; it will ask the user interactively in Pi.

Effects in Pi:

- \`careful\`: destructive bash commands ask for confirmation.
- \`freeze\`: \`edit\` and \`write\` are blocked outside the selected directory.
- \`guard\`: combines \`careful\` plus \`freeze\`.
- \`unfreeze\`: clears the edit boundary.
`;
}

function piUpgradeSkillBody() {
	return `# gstack upgrade in Pi

Upstream gstack's upgrade skill is designed for Claude Code's global gstack skills directory. This Pi package does not write to \`~/.claude\`.

Use the Pi-native upgrade flow instead:

1. Update the Pi package when a new adapter version exists:

   \`\`\`bash
   pi update npm:pi-gstack
   \`\`\`

2. Pull the latest upstream gstack checkout and regenerate Pi skills:

   \`\`\`text
   /gstack-sync
   \`\`\`

3. Rebuild browser/design/PDF binaries when \`/gstack-status\` says the build is missing or stale:

   \`\`\`text
   /gstack-build
   \`\`\`

4. Reload the Pi session if the UI still shows stale skills:

   \`\`\`text
   /reload
   \`\`\`
`;
}

function rewriteGstackPaths(content, repoPath, piSkillsPath) {
	const replacements = [
		["$HOME/.claude/skills/gstack", repoPath],
		["~/.claude/skills/gstack", repoPath],
		[".claude/skills/gstack", repoPath],
		["$HOME/.codex/skills/gstack", repoPath],
		["~/.codex/skills/gstack", repoPath],
		[".claude/skills/review/", `${repoPath}/review/`],
		[".claude/skills/review", `${repoPath}/review`],
		[".agents/skills/gstack", repoPath],
		["$GSTACK_ROOT", repoPath],
		["review/TODOS-format.md", `${repoPath}/review/TODOS-format.md`],
		["review/checklist.md", `${repoPath}/review/checklist.md`],
		["review/design-checklist.md", `${repoPath}/review/design-checklist.md`],
		["qa/templates/", `${repoPath}/qa/templates/`],
		["qa/references/", `${repoPath}/qa/references/`],
		[
			"plan-devex-review/dx-hall-of-fame.md",
			`${repoPath}/plan-devex-review/dx-hall-of-fame.md`,
		],
		["~/.claude/skills", piSkillsPath],
	];

	let out = content;
	for (const [from, to] of replacements) out = out.split(from).join(to);
	return out;
}

function rewritePiHostAssumptions(content) {
	let out = content;
	out = out.replace(
		/^If output shows `UPGRADE_AVAILABLE <old> <new>`: .*Inline upgrade flow.*$/gm,
		"If output shows `UPGRADE_AVAILABLE <old> <new>`: use `/skill:gstack-upgrade` for the Pi-native update flow, or ask whether to run `/gstack-sync` and `/gstack-build`.",
	);
	out = out.replace(
		/Then commit the change: `git add CLAUDE\.md && git commit -m "chore: add gstack skill routing rules to CLAUDE\.md"`/g,
		"Pi adapter: if the user approves routing rules, append them to `AGENTS.md` or `CLAUDE.md`, but do not commit unless the user explicitly asks.",
	);
	out = out.replace(
		/# Vendoring deprecation: detect if CWD has a vendored gstack copy[\s\S]*?echo "VENDORED_GSTACK: \$_VENDORED"/g,
		'# Pi adapter: upstream vendored-gstack detection is disabled because pi-gstack owns the runtime checkout.\necho "VENDORED_GSTACK: no"',
	);
	out = out.replace(
		/If `VENDORED_GSTACK` is `yes`:[\s\S]*?This only happens once per project\. If the marker file exists, skip entirely\./g,
		"Pi adapter: skip upstream vendored-gstack/team-mode migration. pi-gstack owns the runtime checkout under Pi's data directory; never delete that checkout, add Claude-Code-specific project files, or initialize Claude team mode.",
	);
	return out;
}

function rewriteSkillCommands(content, nameMap) {
	const entries = [...nameMap.entries()]
		.filter(([oldName]) => oldName && oldName !== "gstack")
		.sort((a, b) => b[0].length - a[0].length);
	let out = content;
	for (const [oldName, newName] of entries) {
		const patternSource = `(^|[\\s(["'\`])/${escapeRegex(oldName)}(?=$|[\\s,.;:)\\]"'\`])`;
		const pattern = new RegExp(patternSource, "g");
		out = out.replace(pattern, `$1/skill:${newName}`);
	}
	return out;
}

function piCompatibilityNote(repoPath) {
	return `# Pi adapter note

This skill was generated from Garry Tan's [gstack](https://github.com/garrytan/gstack) for Pi.

- Use Pi's lowercase tools (\`read\`, \`bash\`, \`edit\`, \`write\`) when the upstream skill says Read, Bash, Edit, or Write.
- pi-gstack provides compatibility tools named \`AskUserQuestion\`, \`Agent\`, \`Task\`, \`TodoWrite\`, \`ExitPlanMode\`, and \`gstack_safety\` for upstream Claude Code workflows.
- For best \`Agent\` / \`Task\` behavior, install Pi's native subagent package with \`pi install npm:pi-subagents\`. If the \`subagent\` tool is available, prefer it for independent specialist agents; otherwise pi-gstack's built-in \`Agent\` / \`Task\` fallback is supported.
- gstack runtime path: \`${repoPath}\`. This adapter rewrites global \`~/.claude/skills/gstack\` and project \`.claude/skills/gstack\` references to that path and does not install anything into \`~/.claude\`.
- Browser, design, and PDF workflows need gstack's compiled binaries plus Bun/Playwright Chromium. If \`/gstack-status\` reports a missing or stale build, run \`/gstack-build\` once.
`;
}

function sanitizeSkillName(name) {
	const cleaned = String(name)
		.toLowerCase()
		.replace(/[^a-z0-9-]+/g, "-")
		.replace(/-+/g, "-")
		.replace(/^-|-$/g, "");
	return cleaned || "gstack";
}

function normalizeDescription(description) {
	return String(description)
		.replace(/\s+/g, " ")
		.replace(/^[ '"]|[ '"]$/g, "")
		.trim()
		.slice(0, 1000);
}

function wrapDescription(description) {
	const text =
		normalizeDescription(description) ||
		"Garry Tan's gstack skill adapted for Pi.";
	const words = text.split(/\s+/);
	const lines = [];
	let line = "";
	for (const word of words) {
		const candidate = `${line} ${word}`.trim();
		if (candidate.length > 88) {
			if (line) lines.push(line);
			line = word;
		} else {
			line = candidate;
		}
	}
	if (line) lines.push(line);
	return lines.length ? lines : [text];
}

function stripQuotes(value) {
	return value.replace(/^[ '"]|[ '"]$/g, "");
}

function escapeRegex(value) {
	return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

async function getStatus(paths, safety, pi, ctx) {
	const repoExists = await pathExists(path.join(paths.repoDir, ".git"));
	const skillsExist = await pathExists(paths.skillsDir);
	const skillCount = skillsExist
		? await countGeneratedSkills(paths.skillsDir)
		: 0;
	const head = repoExists
		? await safeGit(paths.repoDir, ["rev-parse", "--short", "HEAD"])
		: "missing";
	const branch = repoExists
		? await safeGit(paths.repoDir, ["branch", "--show-current"])
		: "";
	const bunPath = await resolveBunBin();
	const bunVersion = bunPath
		? await commandVersion(bunPath, ["--version"])
		: "";
	const buildStatus = await getBuildStatus(paths);
	const subagentsAvailable = hasPiSubagents(pi);
	const agentSettings = getAgentFallbackSettings(ctx, pi);
	const binaries = requiredBinaries(paths);

	const binaryLines = await Promise.all(
		binaries.map(async ([name, file]) => {
			const ok = await pathExists(file);
			return `- ${name}: ${ok ? "present" : "missing"}`;
		}),
	);

	const shimPath = path.join(paths.piDir, "bin", "bun");
	const shim = await pathExists(shimPath);

	return [
		"gstack for Pi status",
		"",
		`Package data: ${paths.baseDir}`,
		`Repo: ${repoExists ? paths.repoDir : "missing"}`,
		`Git: ${head}${branch ? ` (${branch})` : ""}`,
		`Generated skills: ${skillCount}${DEFAULT_PREFIX ? " (gstack-* names)" : " (short names)"}`,
		`Skills path: ${paths.skillsDir}`,
		`Bun: ${bunVersion ? `${bunVersion} (${bunPath})` : "missing"}`,
		`Bun shim on Pi PATH: ${shim ? shimPath : "missing"}`,
		`Build: ${buildStatus.status}`,
		"",
		"Subagent support:",
		`- pi-subagents: ${subagentsAvailable ? "available" : "not installed"}`,
		"- Agent/Task fallback: ready",
		`- Current mode: ${subagentsAvailable ? "native Pi subagents available; compatibility fallback retained" : "built-in Agent/Task process fallback"}`,
		`- Fallback model: ${agentSettings.model || "Pi default"}`,
		`- Fallback thinking: ${agentSettings.thinking || "Pi default"}`,
		`- Fallback tools: ${agentSettings.tools || "Pi default"}`,
		`- Fallback context: ${agentSettings.contextMode}`,
		`- Fallback concurrency: ${agentSettings.concurrency}`,
		`- Fallback active runs: ${activeAgentFallbacks}`,
		`- Fallback queued runs: ${agentFallbackQueue.length}`,
		`- Fallback artifacts: ${path.join(paths.baseDir, "agent-runs")}`,
		...(subagentsAvailable
			? []
			: [
					`- Recommended install: ${PI_SUBAGENTS_INSTALL_COMMAND}`,
					"- Impact: native parallel/forked specialist agents for review/ship/autoplan",
				]),
		"",
		"Safety modes:",
		`- careful: ${safety?.careful ? "active" : "off"}`,
		`- guard: ${safety?.guard ? "active" : "off"}`,
		`- freeze directory: ${safety?.freezeDir ?? "none"}`,
		"",
		"Binaries:",
		...binaryLines,
		"",
		"Commands:",
		"- /gstack-sync [ref]  clone/update upstream and regenerate Pi skills",
		"- /gstack-build       compile gstack browser/design/pdf binaries with Bun",
		"- /gstack-status      show this status",
	].join("\n");
}

function requiredBinaries(paths) {
	return [
		["browse", path.join(paths.repoDir, "browse", "dist", "browse")],
		["design", path.join(paths.repoDir, "design", "dist", "design")],
		["make-pdf", path.join(paths.repoDir, "make-pdf", "dist", "pdf")],
		[
			"gstack-global-discover",
			path.join(paths.repoDir, "bin", "gstack-global-discover"),
		],
	];
}

async function getBuildStatus(paths) {
	if (!(await pathExists(path.join(paths.repoDir, ".git")))) {
		return { ready: false, status: "missing repo" };
	}
	const missing = [];
	for (const [name, file] of requiredBinaries(paths)) {
		if (!(await pathExists(file))) missing.push(name);
	}
	if (missing.length) {
		return { ready: false, status: `missing (${missing.join(", ")})` };
	}

	let metadata;
	try {
		metadata = JSON.parse(await fs.readFile(buildMetadataPath(paths), "utf8"));
	} catch {
		return {
			ready: false,
			status: "present, metadata missing; run /gstack-build to verify",
		};
	}

	const commit = await safeGit(paths.repoDir, ["rev-parse", "HEAD"]);
	if (
		metadata.gstackCommit &&
		commit !== "unknown" &&
		metadata.gstackCommit !== commit
	) {
		return { ready: false, status: "stale after sync" };
	}
	return {
		ready: true,
		status: `ready (${metadata.builtAt ?? "unknown date"})`,
	};
}

function buildMetadataPath(paths) {
	return path.join(paths.baseDir, ".build.json");
}

async function safeGit(repoDir, args) {
	try {
		const result = await run("git", args, {
			cwd: repoDir,
			timeout: 10 * 1000,
			maxBuffer: 1024 * 1024,
		});
		return result.stdout.trim();
	} catch {
		return "unknown";
	}
}

async function commandVersion(command, args) {
	try {
		const result = await run(command, args, {
			timeout: 10 * 1000,
			maxBuffer: 1024 * 1024,
		});
		return result.stdout.trim() || result.stderr.trim();
	} catch {
		return "";
	}
}

async function countGeneratedSkills(skillsDir) {
	let entries;
	try {
		entries = await fs.readdir(skillsDir, { withFileTypes: true });
	} catch {
		return 0;
	}
	let count = 0;
	for (const entry of entries) {
		if (!entry.isDirectory()) continue;
		if (await pathExists(path.join(skillsDir, entry.name, "SKILL.md")))
			count += 1;
	}
	return count;
}

async function pathExists(file) {
	try {
		await fs.access(file);
		return true;
	} catch {
		return false;
	}
}

async function isDirEmpty(dir) {
	try {
		const entries = await fs.readdir(dir);
		return entries.length === 0;
	} catch {
		return true;
	}
}

function notify(ctx, message, type = "info") {
	if (ctx?.hasUI && ctx.ui?.notify) ctx.ui.notify(message, type);
}

function showMessage(pi, ctx, content) {
	try {
		pi.sendMessage({ customType: "gstack-pi", content, display: true });
	} catch {
		notify(ctx, content.split("\n")[0], "info");
		// In print/json modes, console output is more useful than a dropped UI notification.
		console.log(content);
	}
}

function formatError(error) {
	if (!error) return "unknown error";
	if (error instanceof Error) return error.message;
	return String(error);
}

function tailLines(text, maxLines) {
	const lines = String(text).split(/\r?\n/);
	return lines.slice(Math.max(0, lines.length - maxLines)).join("\n");
}

function truncateText(text, maxChars) {
	const value = String(text ?? "");
	if (value.length <= maxChars) return value;
	return `${value.slice(0, maxChars)}\n\n[truncated ${value.length - maxChars} chars]`;
}

function shellQuote(value) {
	return `'${String(value).replace(/'/g, `'"'"'`)}'`;
}

function prependPath(entry) {
	return `${entry}${path.delimiter}${process.env.PATH || ""}`;
}

function toPosixPath(file) {
	return file.split(path.sep).join("/");
}

function relativePosix(from, to) {
	return toPosixPath(path.relative(from, to));
}
