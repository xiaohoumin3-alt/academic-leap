#!/usr/bin/env node
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import gstackPiExtension, { generatePiSkills } from "../extensions/gstack.js";

const repoDir = process.argv[2] || process.env.GSTACK_REPO_DIR;
if (!repoDir) {
	console.error("Usage: npm run smoke -- /path/to/gstack");
	process.exit(2);
}

const temp = await mkdtemp(path.join(tmpdir(), "pi-gstack-smoke-"));
try {
	const result = await generatePiSkills(
		{
			repoDir,
			skillsDir: path.join(temp, "skills"),
			piDir: path.join(temp, "pi-agent"),
			baseDir: temp,
		},
		{ prefix: true },
	);
	if (result.count < 30)
		throw new Error(`expected at least 30 skills, got ${result.count}`);

	const careful = await readFile(
		path.join(result.skillsDir, "gstack-careful", "SKILL.md"),
		"utf8",
	);
	if (!careful.includes("gstack_safety"))
		throw new Error(
			"gstack-careful should use the Pi safety compatibility tool",
		);

	const upgrade = await readFile(
		path.join(result.skillsDir, "gstack-upgrade", "SKILL.md"),
		"utf8",
	);
	if (!upgrade.includes("pi update npm:pi-gstack"))
		throw new Error("gstack-upgrade should use the Pi-native upgrade flow");

	const rootSkill = await readFile(
		path.join(result.skillsDir, "gstack", "SKILL.md"),
		"utf8",
	);
	for (const forbidden of [
		"Inline upgrade flow",
		"git rm -r",
		"gstack-team-init",
	]) {
		if (rootSkill.includes(forbidden))
			throw new Error(`generated root skill still contains ${forbidden}`);
	}
	if (!rootSkill.includes("pi install npm:pi-subagents"))
		throw new Error("generated root skill should recommend pi-subagents");

	const tools = new Map();
	const commands = new Map();
	const pi = {
		on() {},
		registerTool(tool) {
			tools.set(tool.name, tool);
		},
		registerCommand(name, command) {
			commands.set(name, command);
		},
	};
	gstackPiExtension(pi);
	for (const toolName of [
		"AskUserQuestion",
		"Agent",
		"Task",
		"TodoWrite",
		"ExitPlanMode",
		"gstack_safety",
	]) {
		if (!tools.has(toolName)) throw new Error(`missing tool: ${toolName}`);
	}
	for (const commandName of ["gstack-status", "gstack-sync", "gstack-build"]) {
		if (!commands.has(commandName))
			throw new Error(`missing command: ${commandName}`);
	}
	const questionResult = await tools
		.get("AskUserQuestion")
		.execute(
			"smoke",
			{ question: "Continue?", options: ["Yes", "No"] },
			undefined,
			undefined,
			{ hasUI: false },
		);
	if (!questionResult.content?.[0]?.text.includes("Ask the user directly"))
		throw new Error("AskUserQuestion no-UI fallback did not return a prompt");

	console.log(`Generated ${result.count} skills in ${result.skillsDir}`);
} finally {
	if (!process.env.KEEP_SMOKE_OUTPUT)
		await rm(temp, { recursive: true, force: true });
}
